import ready, { HTML } from './utils';
import initMobileNav from './components/burgerMobile';
import initTabs from './components/tabsInit';
import initAccordion from './components/accInit';
import initOpenClose from './components/openClose';
import initTooltip from './components/tooltip';
import initSlickCarousel from './components/slick';
import initDropDownClasses from './components/hasDropdown';
import initTouchNav from './components/touchNav';

ready(() => {
  HTML.classList.add('is-loaded');
  initMobileNav();
  initTabs();
  initAccordion();
  initOpenClose();
  initSlickCarousel();
  initTooltip();
  initTouchNav();
  initDropDownClasses();
});

const activeClass = 'touch';

function is_touch_enabled() {
  return ( 'ontouchstart' in window ) ||
         ( navigator.maxTouchPoints > 0 ) ||
         ( navigator.msMaxTouchPoints > 0 );
};
console.log(is_touch_enabled());

// if(window.matchMedia("(pointer: coarse)").matches) {
//   console.log('touch');
//   document.documentElement.classList.add(activeClass);
// } else {
//   console.log('desktop');
//   document.documentElement.classList.remove(activeClass);
// }

function isTouchDevice(){
  return window.ontouchstart !== undefined;
}
console.log(isTouchDevice());


function is_touch_device() {
  var prefixes = ' -webkit- -moz- -o- -ms- '.split(' ');
  var mq = function(query) {
    return window.matchMedia(query).matches;
  }

  if (('ontouchstart' in window) || window.DocumentTouch && document instanceof DocumentTouch) {
    return true;
  }

  // include the 'heartz' as a way to have a non matching MQ to help terminate the join
  // https://git.io/vznFH
  var query = ['(', prefixes.join('touch-enabled),('), 'heartz', ')'].join('');
  return mq(query);
}
console.log(is_touch_device());

const newFunc = () => {
  const mouse = new Event("mouseclick");
  const touch = new Event("touch");
  document.addEventListener("pointerdown", ({ pointerType, target }) => {
    if (pointerType === "mouse") target.dispatchEvent(mouse);
    if (pointerType === "touch") target.dispatchEvent(touch);
  });

  const someElement = document.querySelector(".box");
  someElement.addEventListener("mouseover", () => {
    console.log("Clicked with mouse");
    document.documentElement.classList.remove(activeClass);
  });
  someElement.addEventListener("touch", () => {
    console.log("Touched with mobile device");
    document.documentElement.classList.add(activeClass);
  });
  someElement.addEventListener("click", () => {
    console.log("Clicked by some device (we don't know)");
  });
}
