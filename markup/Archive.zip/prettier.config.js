module.exports = {
  printWidth: 180,
  trailingComma: 'es5',
  singleQuote: true,
  semi: true,
};
